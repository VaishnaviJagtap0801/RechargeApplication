package recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import recharge.model.UserLogin;
import recharge.model.UserRegister;

public class UserDaoImpl implements UserDao {
	Connection con=DbConnection.myConnection();
    PreparedStatement p=null;
	@Override
	public int create(List<UserRegister> lst) {
		
		 int i=0;
	     for(UserRegister r:lst)
			{
				try {
					
					p=con.prepareStatement("insert into  UserRegister values(?,?,?,?,?)");
					p.setInt(1,r.getUserId());
					p.setString(2,r.getUname());
					p.setString(3,r.getMobNo());
					p.setString(4,r.getUserEmail());
					p.setString(5,r.getUserPassword());
					
					
				    i=p.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return i;
		
	}
	@Override
	public List<UserRegister> DisplayAll() {
		List<UserRegister> lstall=new ArrayList<UserRegister>();
		String str="select * from UserRegister";
		DbConnection dbobj=new DbConnection();
		Connection con=dbobj.myConnection();
		
		try {
			
			Statement stat=con.createStatement();
			ResultSet rs=stat.executeQuery(str);
			
			while(rs.next())
			{
				UserRegister robj=new UserRegister(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				lstall.add(robj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return lstall;
	}
	@Override
	public String validateuser(UserLogin lobj) {
		System.out.println(lobj.getUserEmail()+"\t"+lobj.getUserPassword());
		String str=null;
		List<UserRegister> lstall=null;
		lstall=DisplayAll();
		
		for(UserRegister r:lstall) {
			if(r.getUserEmail().equals(lobj.getUserEmail())) {
				if(r.getUserPassword().equals(lobj.getUserPassword())) {
					str="valid";
					break;
				}
				else {
					str="invalid password";
				}
			}
			else
			{
				str="invalid username";
			}
		}
		return str;
		
	
	
}

}
