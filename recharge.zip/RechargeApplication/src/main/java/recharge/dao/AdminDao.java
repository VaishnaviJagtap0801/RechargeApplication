package recharge.dao;

import java.util.List;

import recharge.model.RechargePlan;


public interface AdminDao {
	public int addPlan(List<RechargePlan> plan);
	public int delete(int planId);
	public int update(List<RechargePlan> plan);
	public List<RechargePlan> DisplayAll();

}
