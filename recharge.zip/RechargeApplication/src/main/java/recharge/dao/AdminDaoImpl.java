package recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import recharge.model.RechargePlan;


public class AdminDaoImpl implements AdminDao {
	Connection con=DbConnection.myConnection();
    PreparedStatement p=null;

	@Override
	public int addPlan(List<RechargePlan> plan) {
		 int i=0;
	     for(RechargePlan r:plan)
			{
				try {
					
					p=con.prepareStatement("insert into  RechargePlan values(?,?,?,?)");
					p.setInt(1,r.getPlanId());
					p.setString(2,r.getPlanName());
					p.setString(3,r.getValidity());
					p.setFloat(4,r.getPlanPrice());
					
				    i=p.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return i;
		
		
	}

	@Override
	public int delete(int planId) {
		try {
			p=con.prepareStatement("delete from RechargePlan where planId=?");
			p.setInt(1,planId);
			int i=p.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return planId;
		
		
		
	}

	@Override
	public int update(List<RechargePlan> plan) {
		Connection con=DbConnection.myConnection();
	     List<RechargePlan> listplan=new ArrayList<RechargePlan>();
	     int i=0;
	     
	    	 try {

	    	 for(RechargePlan robj:plan) {
	    	   p=con.prepareStatement("update RechargePlan set planName=?,validity=?,planPrice=? where planId=?");
			   p.setString(1, robj.getPlanName());
			   p.setString(2, robj.getValidity());
		       p.setFloat(3, robj.getPlanPrice());
		       p.setInt(4, robj.getPlanId());
		    	 
		       i=p.executeUpdate();
	    	 }	 
		    	 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
	     }
			return i;
			
		}

	@Override
	public List<RechargePlan> DisplayAll() {
		List<RechargePlan> lstall=new ArrayList<RechargePlan>();
		String str="select * from RechargePlan";
		DbConnection dbobj=new DbConnection();
		Connection con=dbobj.myConnection();
		
		try {
			
			Statement stat=con.createStatement();
			ResultSet rs=stat.executeQuery(str);
			
			while(rs.next())
			{
				RechargePlan robj=new RechargePlan(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getFloat(4));
				lstall.add(robj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return lstall;
	}
	

}

		
	


