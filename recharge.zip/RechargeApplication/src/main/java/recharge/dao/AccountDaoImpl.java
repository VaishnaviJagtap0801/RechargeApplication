package recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import recharge.model.Account;

public class AccountDaoImpl implements Accountdao {
	Connection con=DbConnection.myConnection();
    PreparedStatement p=null;
	@Override
	public int create(List<Account> lst) {
		
		 int i=0;
	     for(Account a:lst)
			{
				try {
					
					p=con.prepareStatement("insert into  Account values(?,?,?)");
					p.setString(1,a.getName());
					p.setString(2,a.getMobNo());
					p.setInt(3,a.getAmmount());
			
					
				    i=p.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return i;
	}
	
	

}
