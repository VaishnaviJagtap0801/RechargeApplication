package recharge.dao;

import java.util.List;

import recharge.model.Login;
import recharge.model.Register;

public interface RegisterDao {
	public int create(List<Register> lst);
	public int Login(List<Register> list);
	

}
