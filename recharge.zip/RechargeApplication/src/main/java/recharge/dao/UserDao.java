package recharge.dao;

import java.util.List;

import recharge.model.UserLogin;
import recharge.model.UserRegister;

public interface UserDao {
	
	public int create(List<UserRegister> lst);
	public List<UserRegister> DisplayAll();
	public String validateuser(UserLogin lobj);
	

}
