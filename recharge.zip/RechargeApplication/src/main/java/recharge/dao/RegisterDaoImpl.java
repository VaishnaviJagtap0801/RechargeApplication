package recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import recharge.model.Login;
import recharge.model.Register;

public class RegisterDaoImpl implements RegisterDao {
	Connection con=DbConnection.myConnection();
    PreparedStatement p=null;
	@Override
	public int create(List<Register> lst) {
	     int i=0;
	     for(Register r:lst)
			{
				try {
					
					p=con.prepareStatement("insert into  Register values(?,?,?,?)");
					p.setInt(1,r.getRegId());
					p.setString(2,r.getRegName());
					p.setString(3,r.getRegEmail());
					p.setString(4,r.getRegPassword());
					
				    i=p.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return i;

}

	@Override
	public int Login(List<Register> list) {
		Connection con=DbConnection.myConnection();
		int i=0;
		
		try {
			for(Register reg:list)
			{
				p=con.prepareStatement("Select regPassword from Register where regName=? AND regEmail=?");
				p.setString(1, reg.getRegName());
				p.setString(2,reg.getRegEmail());
		
				ResultSet rs=p.executeQuery();
				while(rs.next()) {
					String str=rs.getString("regPassword");
					if(reg.getRegPassword().equals(str)) {
						i=1;
						return i;
						}
						
					}
				}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;	
}
	
}