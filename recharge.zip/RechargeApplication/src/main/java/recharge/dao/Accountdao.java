package recharge.dao;

import java.util.List;

import recharge.model.Account;


public interface Accountdao {
	public int create(List<Account> lst);

}
