package recharge.dao;

import java.util.List;

import recharge.model.Contact;



public interface ContactDao {
	public int create(List<Contact> lst);

}
