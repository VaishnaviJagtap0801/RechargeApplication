package recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import recharge.model.Contact;


public class ContactDaoImpl implements ContactDao {
	Connection con=DbConnection.myConnection();
    PreparedStatement p=null;
	@Override
	public int create(List<Contact> lst) {
		int i=0;
	     for(Contact r:lst)
			{
				try {
					
					p=con.prepareStatement("insert into  Contact values(?,?,?)");
					p.setString(1,r.getFullName());
					p.setString(2,r.getEmail());
					p.setString(3,r.getTextArea());
					
				    i=p.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return i;
		
	}
	

}
