package recharge.servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import recharge.dao.RegisterDao;
import recharge.dao.RegisterDaoImpl;
import recharge.model.Register;
import javax.servlet.ServletRequest;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String regName=request.getParameter("regName");
		String regEmail=request.getParameter("regEmail");
		String regPassword=request.getParameter("regPassword");
		
		Register reg=new Register(0, regName, regEmail, regPassword);
		List <Register> list=new ArrayList<Register>();
		list.add(reg);
		PrintWriter pw=response.getWriter();
		RegisterDao rdao=new RegisterDaoImpl();
		int i=rdao.Login(list);
		if(i>0)
		{
			RequestDispatcher rd=request.getRequestDispatcher("AdminDashboard.jsp");
			rd.forward(request,response);
			//response.sendRedirect("AdminDashboard.jsp");
			
		}
		else
		{
			response.setContentType("text/html");
			pw.print("<h1 style='color:red'>wrong Email or password!!!</h1>");
			RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
			rd.include(request,response);
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
