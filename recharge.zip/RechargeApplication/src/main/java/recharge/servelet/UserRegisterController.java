package recharge.servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import recharge.dao.UserDao;
import recharge.dao.UserDaoImpl;
import recharge.model.UserRegister;



/**
 * Servlet implementation class UserRegisterController
 */
@WebServlet("/UserRegisterController")
public class UserRegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserRegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int userId=Integer.parseInt(request.getParameter("userId"));
		String uname=request.getParameter("uname");
		String mobNo=request.getParameter("mobNo");
		String userEmail=request.getParameter("userEmail");
		String userPassword=request.getParameter("userPassword");
		
		UserRegister robj=new UserRegister(userId, uname, mobNo, userEmail, userPassword);
		List<UserRegister> lst=new ArrayList<UserRegister>();
		lst.add(robj);
	    
		PrintWriter pw=response.getWriter();
		UserDao rdao=new UserDaoImpl();
		int i=rdao.create(lst);
		
		if(i>0)
		{
			response.sendRedirect("Account.jsp");
		}
		else
		{
			pw.println("invalid details..");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
