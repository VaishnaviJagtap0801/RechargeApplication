package recharge.servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import recharge.dao.ContactDao;
import recharge.dao.ContactDaoImpl;
import recharge.model.Contact;


/**
 * Servlet implementation class ContactController
 */
@WebServlet("/ContactController")
public class ContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContactController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String fullName=request.getParameter("fullName");
		String Email=request.getParameter("Email");
		String textArea=request.getParameter("textArea");
		
		Contact robj=new Contact(fullName,Email,textArea);
		List<Contact> lst=new ArrayList<Contact>();
		lst.add(robj);
	    
		ContactDao rdao=new ContactDaoImpl();
		int i=rdao.create(lst);
		
		
        PrintWriter pw=response.getWriter();
		
		if(i>0)
		{
			pw.println("Done");
		}
		else
		{
			pw.println("Done");
		}
		
		
			
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
