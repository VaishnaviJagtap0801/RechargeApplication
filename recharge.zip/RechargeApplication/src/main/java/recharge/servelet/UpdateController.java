package recharge.servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import recharge.dao.AdminDao;
import recharge.dao.AdminDaoImpl;
import recharge.model.RechargePlan;


/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int planId=Integer.parseInt(request.getParameter("planId"));
		String planName=request.getParameter("planName");
		String validity=request.getParameter("validity");
		float planPrice=Float.parseFloat(request.getParameter("planPrice"));
		
		RechargePlan robj=new RechargePlan(planId, planName, validity, planPrice);
		List<RechargePlan> plan=new ArrayList<RechargePlan>();
		plan.add(robj);
		
		AdminDao adao=new AdminDaoImpl();
		 PrintWriter pw=response.getWriter();
		 int i=adao.update(plan);
		 if(i>0)
		 {
			 pw.print("plan updated...");
		
		 }
		 else
		 {
			 pw.print("plan not updated");
			 
		 }
		 
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
