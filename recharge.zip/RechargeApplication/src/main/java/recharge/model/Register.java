package recharge.model;

public class Register {
	private int regId;
	private String regName;
	private String regEmail;
	private String regPassword;
	public Register(int regId, String regName, String regEmail, String regPassword) {
		super();
		this.regId = regId;
		this.regName = regName;
		this.regEmail = regEmail;
		this.regPassword = regPassword;
	}
	public int getRegId() {
		return regId;
	}
	public void setRegId(int regId) {
		this.regId = regId;
	}
	public String getRegName() {
		return regName;
	}
	public void setRegName(String regName) {
		this.regName = regName;
	}
	public String getRegEmail() {
		return regEmail;
	}
	public void setRegEmail(String regEmail) {
		this.regEmail = regEmail;
	}
	public String getRegPassword() {
		return regPassword;
	}
	public void setRegPassword(String regPassword) {
		this.regPassword = regPassword;
	}
	
	

}
