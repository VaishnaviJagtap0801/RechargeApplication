package recharge.model;

public class Contact {
	private String fullName;
	private String Email;
	private String textArea;
	public Contact(String fullName, String email, String textArea) {
		super();
		this.fullName = fullName;
		Email = email;
		this.textArea = textArea;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getTextArea() {
		return textArea;
	}
	public void setTextArea(String textArea) {
		this.textArea = textArea;
	}
	

	

}
