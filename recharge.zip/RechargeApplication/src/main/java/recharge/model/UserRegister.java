package recharge.model;

public class UserRegister {
	
	private int userId;
	private String uname;
	private String mobNo;
	private String userEmail;
	private String userPassword;
	public UserRegister(int userId, String uname, String mobNo, String userEmail, String userPassword) {
		super();
		this.userId = userId;
		this.uname = uname;
		this.mobNo = mobNo;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	
}
