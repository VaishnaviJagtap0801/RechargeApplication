package recharge.model;

public class Admin {
	private int adId;
	private String adName;
	private String adpassword;
	private String adEmail;
	public Admin(int adId, String adName, String adpassword, String adEmail) {
		super();
		this.adId = adId;
		this.adName = adName;
		this.adpassword = adpassword;
		this.adEmail = adEmail;
	}
	public int getAdId() {
		return adId;
	}
	public void setAdId(int adId) {
		this.adId = adId;
	}
	public String getAdName() {
		return adName;
	}
	public void setAdName(String adName) {
		this.adName = adName;
	}
	public String getAdpassword() {
		return adpassword;
	}
	public void setAdpassword(String adpassword) {
		this.adpassword = adpassword;
	}
	public String getAdEmail() {
		return adEmail;
	}
	public void setAdEmail(String adEmail) {
		this.adEmail = adEmail;
	}

}
