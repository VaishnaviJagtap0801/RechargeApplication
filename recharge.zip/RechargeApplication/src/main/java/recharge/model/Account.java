package recharge.model;

public class Account {
	private String name;
	private String mobNo;
	private int ammount;
	public Account(String name, String mobNo, int ammount) {
		super();
		this.name = name;
		this.mobNo = mobNo;
		this.ammount = ammount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public int getAmmount() {
		return ammount;
	}
	public void setAmmount(int ammount) {
		this.ammount = ammount;
	}

	

}
