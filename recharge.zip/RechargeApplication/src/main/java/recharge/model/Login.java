package recharge.model;

public class Login {
	private String regName;
	private String regEmail;
	private String regPassword;
	public Login(String regName, String regEmail, String regPassword) {
		super();
		this.regName = regName;
		this.regEmail = regEmail;
		this.regPassword = regPassword;
	}
	public String getRegName() {
		return regName;
	}
	public void setRegName(String regName) {
		this.regName = regName;
	}
	public String getRegEmail() {
		return regEmail;
	}
	public void setRegEmail(String regEmail) {
		this.regEmail = regEmail;
	}
	public String getRegPassword() {
		return regPassword;
	}
	public void setRegPassword(String regPassword) {
		this.regPassword = regPassword;
	}

	
}
