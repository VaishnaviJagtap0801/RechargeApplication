package recharge.model;

public class RechargePlan {
       private int planId;
       private String planName;
       private String validity;
       private float planPrice;
	public RechargePlan(int planId, String planName, String validity, float planPrice) {
		super();
		this.planId = planId;
		this.planName = planName;
		this.validity = validity;
		this.planPrice = planPrice;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getValidity() {
		return validity;
	}
	public void setValidity(String validity) {
		this.validity = validity;
	}
	public float getPlanPrice() {
		return planPrice;
	}
	public void setPlanPrice(float planPrice) {
		this.planPrice = planPrice;
	}
   
}
